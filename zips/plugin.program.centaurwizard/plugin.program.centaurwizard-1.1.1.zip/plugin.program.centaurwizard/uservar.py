'''#####-----Build File-----#####'''
buildfile = 'https://wlft.b-cdn.net/builds.xml'

'''#####-----Videos File-----#####'''
videos_url = 'http://CHANGEME'

'''#####-----Notification File-----#####'''
notify_url  = 'https://wlft.b-cdn.net/notify.txt'

'''#####-----Changelog Directory-----#####'''
changelog_dir  = 'http://CHANGEME/'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']