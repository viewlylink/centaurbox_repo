import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://wlft.b-cdn.net/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://wlft.b-cdn.net/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']