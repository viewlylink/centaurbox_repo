# plugin.program.centaurwizard
Simple Wizard for Kodi