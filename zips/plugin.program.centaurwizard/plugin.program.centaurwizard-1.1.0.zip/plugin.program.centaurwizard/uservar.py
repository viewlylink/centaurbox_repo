import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://welivefortech.com/dl/wizard/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://welivefortech.com/dl/wizard/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']